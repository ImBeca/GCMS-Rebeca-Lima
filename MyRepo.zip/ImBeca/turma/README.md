# GCMS-2023-2
Repositório da turma de GCMS do IFPE-Recife, 2023.2!

## Colaboradores
Coloque seu nome abaixo se você é um dos colaboradores do repositório:
* Ramide Dantas (@ramidedantas, dono)
* NOME SOBRENOME (@login)
* Luciano Filho (@LucianoSegundo)
* Rafael Marques (@rfdsm)
* Maiara Santos (@aguedamaiara)
* Rebeca Jamilly (@ImBeca)
* Alane Alves (@alanealvess)
* André Pereira da Silva (@silvaandrep)
* Flávio Vieira (@flaviovieiraj)
* Wallisson Rocha (@PilzTol)
* Filipe Henrique de Lima(@fh3mrique)
